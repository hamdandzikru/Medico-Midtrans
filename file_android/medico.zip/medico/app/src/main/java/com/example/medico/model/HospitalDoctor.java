package com.example.medico.model;

public class HospitalDoctor{
    private String nama;

}
