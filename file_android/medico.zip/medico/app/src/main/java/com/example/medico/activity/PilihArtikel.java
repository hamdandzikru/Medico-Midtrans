package com.example.medico.activity;

import android.app.Activity;

public class PilihArtikel extends Activity {
}
