package com.example.medico.model;

public class HospitalContact {
    private String IGD;
    private String information;
    private String email;

    public HospitalContact(){}

    public String getIGD() {
        return IGD;
    }

    public String getInformation() {
        return information;
    }

    public String getEmail() {
        return email;
    }
}
