package com.example.medico.model;

public class HospitalServices {
    public int cost;
    public String ServiceName;
    public String ServiceDesc;
}
