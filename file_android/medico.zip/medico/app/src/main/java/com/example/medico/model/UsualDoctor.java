package com.example.medico.model;

public class UsualDoctor extends Doctor {
    private String address;
    private float rating;
    private int GiveRating;
}
