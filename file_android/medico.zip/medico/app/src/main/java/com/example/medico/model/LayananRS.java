package com.example.medico.model;

public class LayananRS {
    private String desc;
    private String harga;
    private String kelompok;
    private String nama;

    public LayananRS(){
        //
    }

    public String getDesc() {
        return desc;
    }

    public String getHarga() {
        return harga;
    }

    public String getKelompok() {
        return kelompok;
    }

    public String getNama() {
        return nama;
    }
}
