package com.example.medico.model;

public class DemoItem {
    public String title;
    public String Description;
    public String imageUrl;

    public DemoItem(String title, String Description, String imageUrl) {
        this.title = title;
        this.Description = Description;
        this.imageUrl = imageUrl;
    }
}
