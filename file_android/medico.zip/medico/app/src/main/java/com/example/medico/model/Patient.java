package com.example.medico.model;

public class Patient {
    private int MedicalRecordNumber;
    private String FullName;
    private String NIK;
    private String BirthPlace;
    private Date BornDay;
    private String address;
}
